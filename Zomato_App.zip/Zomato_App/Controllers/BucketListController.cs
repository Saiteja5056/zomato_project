﻿using Microsoft.AspNetCore.Mvc;
using Zomato_App.DTO;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BucketListController : ControllerBase
    {
        private readonly IBucketListRepository _bucketListRepository;
        public BucketListController(IBucketListRepository bucketListRepository)
        {
            _bucketListRepository = bucketListRepository;
        }

        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var items = await _bucketListRepository.GetAllAsync();
            return Ok(items);
        }

        [HttpGet, Route("GetById")]
        public async Task<IActionResult> GetById(int id)
        {
            var item = await _bucketListRepository.GetByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }

        [HttpPost, Route("AddItem")]
        public async Task<IActionResult> Add([FromBody] BucketListDto bucketListDto)
        {
            if (bucketListDto == null)
            {
                return BadRequest("BucketListDto cannot be null.");
            }

            var item = new BucketList
            {
                UserID = bucketListDto.UserID,
                RestaurantId = bucketListDto.RestaurantId,
                ItemId = bucketListDto.ItemId,
                Quantity = bucketListDto.Quantity,
     
                DateAdded = DateTime.Now,
                // The Name is automatically set via navigation property, no need to set manually
            };

            await _bucketListRepository.AddAsync(item);
            return Ok();
        }

        [HttpPut, Route("UpdateItem")]
        public async Task<IActionResult> Update([FromBody] BucketListDto bucketListDto)
        {
            if (bucketListDto == null)
            {
                return BadRequest("BucketListDto cannot be null.");
            }

            var item = new BucketList
            {
                BucketListID = bucketListDto.BucketListID,
                UserID = bucketListDto.UserID,
                RestaurantId = bucketListDto.RestaurantId,
                ItemId = bucketListDto.ItemId,
                Quantity = bucketListDto.Quantity,
                DateAdded = bucketListDto.DateAdded,
                // The Name is automatically set via navigation property, no need to set manually
            };

            await _bucketListRepository.UpdateAsync(item);
            return NoContent();
        }



        [HttpDelete, Route("DeleteItem")]
        public async Task<IActionResult> Delete(int id)
        {
            await _bucketListRepository.DeleteAsync(id);
            return NoContent(); 
        }
    }
}
