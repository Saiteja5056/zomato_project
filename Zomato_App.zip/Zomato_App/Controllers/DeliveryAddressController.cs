﻿using Microsoft.AspNetCore.Mvc;
using Zomato_App.DTO;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeliveryAddressController : ControllerBase
    {
        private readonly IDeliveryAddressRepository _repository;

        public DeliveryAddressController(IDeliveryAddressRepository repository)
        {
            _repository = repository;
        }

        [HttpPost, Route("AddAddress")]
        public async Task<ActionResult<DeliveryAddress>> AddAddress([FromBody] DeliveryAddressDto deliveryAddressDto)
        {
            if (deliveryAddressDto == null)
            {
                return BadRequest("DeliveryAddressDto cannot be null.");
            }

            var address = new DeliveryAddress
            {
                DeliveryPersonnelID = deliveryAddressDto.DeliveryPersonnelID,
                UserID = deliveryAddressDto.UserID,
                Name = deliveryAddressDto.Name,
            };

            await _repository.AddAsync(address);
            return Ok();
        }

        [HttpPut, Route("UpdateAddress")]
        public async Task<ActionResult<DeliveryAddress>> Update([FromBody] DeliveryAddressDto deliveryAddressDto)
        {
            if (deliveryAddressDto == null)
            {
                return BadRequest("DeliveryAddressDto cannot be null.");
            }

            var address = new DeliveryAddress
            {
                DeliveryPersonnelID = deliveryAddressDto.DeliveryPersonnelID,
                UserID = deliveryAddressDto.UserID,
                Name = deliveryAddressDto.Name,
            };

            await _repository.UpdateAsync(address);
            return Ok();
        }

        [HttpDelete, Route("DeleteAddress")]
        public async Task<ActionResult<DeliveryAddress>> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return Ok();
        }
    }
}
