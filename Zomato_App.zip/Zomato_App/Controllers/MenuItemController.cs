﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuItemController : ControllerBase
    {
        private readonly IMenuItemrepository _menuItemRepository;

        public MenuItemController(IMenuItemrepository menuItemRepository)
        {
            _menuItemRepository = menuItemRepository;
        }

        [HttpGet,Route("GetById")]
        public async Task<ActionResult<MenuItem>> GetById(int id)
        {
            var menuItem = await _menuItemRepository.GetByIdAsync(id);
            if (menuItem == null)
            {
                return NotFound();
            }
            return Ok(menuItem);
        }

        [HttpGet,Route("GetAll")]
        public async Task<ActionResult<IEnumerable<MenuItem>>> GetAll()
        {
            var menuItems = await _menuItemRepository.GetAllAsync();
            return Ok(menuItems);
        }

        [HttpPost,Route("AddItem")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<MenuItem>> Add(MenuItem menuItem)
        {
            await _menuItemRepository.AddAsync(menuItem);
            return CreatedAtAction(nameof(GetById), new { id = menuItem.ItemId }, menuItem);
        }

        [HttpPut,Route("Update")]
        
        public async Task<IActionResult> Update(int id, MenuItem menuItem)
        {
            if (id != menuItem.ItemId)
            {
                return BadRequest();
            }

            await _menuItemRepository.UpdateAsync(menuItem);
            return NoContent();
        }

        [HttpDelete,Route("Delete")]
        [Authorize(Roles = "User,admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _menuItemRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}
