﻿using Microsoft.AspNetCore.Mvc;
using Zomato_App.DTO;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderrepository _orderRepository;

        public OrderController(IOrderrepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet,Route("GetById")]
        public async Task<ActionResult<Order>> GetById(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return Ok(order);
        }

        [HttpGet,Route("GetAll")]
        public async Task<ActionResult<IEnumerable<Order>>> GetAll()
        {
            var orders = await _orderRepository.GetAllAsync();
            return Ok(orders);
        }

        [HttpPost,Route("Add")]
        public async Task<ActionResult<Order>> Add(OrderDto orderDto)
        {
            var ORDER = new Order
            {
                OrderId = orderDto.OrderId,
                RestaurantId = orderDto.RestaurantId,
                UserId = orderDto.UserId,
                TotalAmount = orderDto.TotalAmount,
                OrderStatus = orderDto.OrderStatus,
                PaymentStatus = orderDto.PaymentStatus
            };
            await _orderRepository.AddAsync(ORDER);
            return CreatedAtAction(nameof(GetById), new { id = orderDto.OrderId }, orderDto);
        }

        [HttpPut,Route("Update")]
        public async Task<IActionResult> Update(int id, Order order)
        {
            if (id != order.OrderId)
            {
                return BadRequest();
            }

            await _orderRepository.UpdateAsync(order);
            return NoContent();
        }

        [HttpDelete,Route("Delete")]
        public async Task<IActionResult> Delete(int id)
        {
            await _orderRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}
