﻿using Microsoft.AspNetCore.Mvc;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

using System.Collections.Generic;
using System.Threading.Tasks;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemController : ControllerBase
    {
        private readonly IOrderItemrepository _orderItemRepository;

        public OrderItemController(IOrderItemrepository orderItemRepository)
        {
            _orderItemRepository = orderItemRepository;
        }

        [HttpGet,Route("GetById")]
        public async Task<ActionResult<OrderItem>> GetById(int id)
        {
            var orderItem = await _orderItemRepository.GetByIdAsync(id);
            if (orderItem == null)
            {
                return NotFound();
            }
            return Ok(orderItem);
        }

        [HttpGet,Route("GetAll")]
        public async Task<ActionResult<IEnumerable<OrderItem>>> GetAll()
        {
            var orderItems = await _orderItemRepository.GetAllAsync();
            return Ok(orderItems);
        }

        [HttpPost,Route("Add")]
        public async Task<ActionResult<OrderItem>> Add(OrderItem orderItem)
        {
            await _orderItemRepository.AddAsync(orderItem);
            return CreatedAtAction(nameof(GetById), new { id = orderItem.OrderItemId }, orderItem);
        }

        [HttpPut,Route("Update")]
        public async Task<IActionResult> Update(int id, OrderItem orderItem)
        {
            if (id != orderItem.OrderItemId)
            {
                return BadRequest();
            }

            await _orderItemRepository.UpdateAsync(orderItem);
            return NoContent();
        }

        [HttpDelete,Route("Delete")]
        public async Task<IActionResult> Delete(int id)
        {
            await _orderItemRepository.DeleteAsync(id);
            return NoContent();
        }
    }

}




