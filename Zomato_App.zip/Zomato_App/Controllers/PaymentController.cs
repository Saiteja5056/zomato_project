﻿using Microsoft.AspNetCore.Mvc;
using Zomato_App.DTO;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentRepository _paymentRepository;

        public PaymentController(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

       

        
        [HttpPost,Route("AddPaymentMethod")]
        public async Task<ActionResult<Payment>> Add([FromBody]PaymentDto paymentDto)
        {
            var payment = new Payment
            { 
                PaymentId = paymentDto.PaymentId,
                UserId = paymentDto.UserId,
                OrderId=paymentDto.OrderId,
                Amount = paymentDto.Amount,
                PaymentMethod = paymentDto.PaymentMethod,
                Status= paymentDto.Status,
                
            };


            await _paymentRepository.AddAsync(payment);
            return Ok();
        }

      
        [HttpPut,Route("Update")]
        public async Task<IActionResult> Update(int id, PaymentDto paymentDto)
        {
            var payment = new Payment
            {
                PaymentId = paymentDto.PaymentId,
                UserId = paymentDto.UserId,
                OrderId = paymentDto.OrderId,
                Amount = paymentDto.Amount,
                PaymentMethod = paymentDto.PaymentMethod,
                Status = paymentDto.Status,

            };
            if (id != paymentDto.PaymentId)
            {
                return BadRequest();
            }

            await _paymentRepository.UpdateAsync(payment);
            return NoContent();
        }

       
        [HttpDelete,Route("Delete")]
        public async Task<IActionResult> Delete(int id)
        {
            await _paymentRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}
