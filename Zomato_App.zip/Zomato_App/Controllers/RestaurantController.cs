﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Controllers
{
    public class RestaurantController : Controller
    {
        private readonly IRestaurantrepository repository;
        public RestaurantController(IRestaurantrepository repository)
        {
            this.repository = repository;
        }
        [HttpPost, Route("AddRestaurant")]
       
        public IActionResult AddRestaurant([FromBody] Restaurant restaurant)
        {

            repository.AddRestaurant(restaurant);
            return Ok();
        }
        [HttpGet, Route("GetAllRestaurants")]
        public IActionResult GetAll()
        {
            var restaurant = repository.GetAll();
            return Ok(restaurant);
        }
        [HttpGet, Route("getbyid")]
        public IActionResult Getbyid(int id)
        {
            var restaurant = repository.GetById(id);
            return Ok(restaurant);
        }
        [HttpPut, Route("UpdateRestaurant")]
        [Authorize(Roles = "Admin,admin")]
        public IActionResult Update(Restaurant restaurant)
        {
            repository.Update(restaurant);
            return Ok();
        }
        [HttpDelete, Route("DeleteRestaurant")]
        [Authorize(Roles = "Admin,admin")]
        public IActionResult Delete(int id)
        {
            repository.DeleteById(id);
            return Ok();
        }
    }
}
