﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Zomato_App.DTO;
using Zomato_App.Entities;
using Zomato_App.IRepositories;
using Zomato_App.Models;

namespace Zomato_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserrepository _userRepository;
        private  IConfiguration _configuration;

        public UserController(IUserrepository userRepository, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _configuration = configuration;
        }

        [HttpGet,Route("GetById")]
        public async Task<ActionResult<User>> GetById(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }

        [HttpGet,Route("GetAllUSers")]
        public async Task<ActionResult<IEnumerable<User>>> GetAll()
        {
            var users = await _userRepository.GetAllAsync();
            return Ok(users);
        }

        [HttpPost,Route("AddUser")]
        public async Task<ActionResult<UserDto>> Add(UserDto userDto)
        {
            try {
                var user = new User
                {
                    Name = userDto.Name,
                    Email = userDto.Email,
                    PhoneNumber = userDto.PhoneNumber,
                    Password = userDto.Password,
                    Role = userDto.Role,

                };

                await _userRepository.AddAsync(user);

                userDto.UserId = user.UserId;
                return CreatedAtAction(nameof(GetById), new { id = user.UserId }, userDto);

            }
            catch (DbUpdateException ex)
            {
                var sqlException = ex.InnerException as SqlException;
                if (sqlException != null)
                {
                    if (sqlException.Number == 2627 || sqlException.Number == 2601)
                    {
                        if (sqlException.Message.Contains("Email"))
                        {
                            return Conflict(new { message = "The email address is already in use." });
                        }
                        
                    }
                }
                return StatusCode(500, new { message = "An error occurred while processing your request." });
            }
        }

        [HttpPut,Route("UpdateUser")]
        [Authorize("User,Admin")]
        public async Task<IActionResult> Update(int id, UserDto userDto)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                return NotFound(); 
            }           
            user.Name = userDto.Name;
            user.Password = userDto.Password;
           
            await _userRepository.UpdateAsync(user);
            return Ok(user);
        }

        [HttpDelete,Route("DeleteUser")]
        public async Task<IActionResult> Delete(int id)
        {
            await _userRepository.DeleteAsync(id);
            return NoContent();
        }
        [HttpPost,Route("Validate")]
        public async Task<IActionResult> Validate(Login login)
        {
            LoginResponse LoginReponse = null;
            var user = await _userRepository.Validate(login.Email, login.Password);
            if (user != null)
            {
                LoginReponse = new LoginResponse()
                {
                    UserId = user.UserId,
                    UserName = user.Name,
                    Password = user.Password,
                    Email = user.Email,
                    Role = user.Role,
                    PhoneNumber = user.PhoneNumber,
                    Token = GetToken(user)
                };
            }
            return Ok(LoginReponse);
        }
        private string GetToken(User user )
        {
            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];
            var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);
            //Header section
            var signingCredentials = new SigningCredentials(
                new SymmetricSecurityKey(key),
                SecurityAlgorithms.HmacSha512Signature
            );
            //Payload section
            var subject = new ClaimsIdentity(new[]
            {
        // new Claim(ClaimTypes.NameIdentifier, issuer),
                 new Claim(ClaimTypes.Email,user.Email),
                 new Claim(ClaimTypes.Role, user.Role),
             });

            var expires = DateTime.UtcNow.AddMinutes(10);//token will expire after 10min

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = subject,
                Expires = expires,
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = signingCredentials
            };
            //generate token using tokenDescription
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = tokenHandler.WriteToken(token);
            return jwtToken;
        }
    }
}
