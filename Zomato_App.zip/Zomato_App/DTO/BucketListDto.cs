﻿public class BucketListDto
{
    public int BucketListID { get; set; }
    public int UserID { get; set; }
    public int RestaurantId { get; set; }
    public int ItemId { get; set; }
    public string Name { get; set; }
    public int Quantity { get; set; }
    public DateTime DateAdded { get; set; }
}
