﻿using System.ComponentModel.DataAnnotations.Schema;
using Zomato_App.Entities;

namespace Zomato_App.DTO
{
    public class DeliveryAddressDto
    {
        public int DeliveryPersonnelID { get; set; }
        public int UserID { get; set; }
        public string Name { get; set; }
    }
}
