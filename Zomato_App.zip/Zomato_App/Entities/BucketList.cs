﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Zomato_App.Entities;

public class BucketList
{
    [Key]
    public int BucketListID { get; set; }

    [ForeignKey("User")]
    public int UserID { get; set; }
    public User User { get; set; }

    [ForeignKey("MenuItem")]
    public int ItemId { get; set; } // Ensure this is an int
    public MenuItem MenuItem { get; set; }

    [ForeignKey("Restaurant")]
    public int RestaurantId { get; set; }
    public Restaurant Restaurant { get; set; }

    public int Quantity { get; set; }
    public DateTime DateAdded { get; set; }

}
