﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Zomato_App.Entities
{
    public class DeliveryAddress
    {
        [Key]
        public int DeliveryPersonnelID { get; set; }
        [ForeignKey("Users")]
        public int UserID { get; set; }
        public User User { get; set; } 

        public string Name { get; set; }

    }
}
