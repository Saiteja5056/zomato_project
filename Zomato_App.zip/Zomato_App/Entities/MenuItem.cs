﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Zomato_App.Entities
{
    public class MenuItem
    {
        [Key]
        public int ItemId { get; set; }


        public int MenuId { get; set; }
        [ForeignKey("Restaurant")]
        public int RestaurantId { get; set; }

        [Required]
        public string Name { get; set; }

        public string Description { get; set; }
        public int Price { get; set; }

        public int? Calories { get; set; }
        public bool Availability { get; set; }
        
      
    }
}
