﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Zomato_App.Entities
{
    public class Restaurant
    {
        [Key]

        public int RestaurantId { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(200)]
        public string Address { get; set; }

        [Required]
        [StringLength(15)]
        public string PhoneNumber { get; set; }

        [StringLength(100)]
        public string Cuisine { get; set; }

        [Range(1, 5)]
        public double Rating { get; set; } = 0;

        [StringLength(500)]
        public string Description { get; set; }

        public bool IsOpen { get; set; } = true;

    }
}

