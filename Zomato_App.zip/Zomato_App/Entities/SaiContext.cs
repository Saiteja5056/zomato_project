﻿using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;


namespace Zomato_App.Entities
{
    public class SaiContext :DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Restaurant> Restaurants { get; set; }
        public DbSet<MenuItem> MenuItems { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        
        public DbSet<Payment> Payments { get; set; }
        public DbSet<DeliveryAddress> DeliveryAddresses { get; set; }
        
        public DbSet<BucketList> BucketLists { get; set; }
        


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=LAPTOP-7592U22E\\SQLEXPRESS01;Initial Catalog=Zomata;Integrated Security=True;Trust Server Certificate=True");

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();
        }


    }
}
