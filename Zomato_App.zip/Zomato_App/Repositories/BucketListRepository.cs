﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Zomato_App.Entities;
using Zomato_App.IRepositories;

namespace Zomato_App.Repositories
{
    public class BucketListRepository : IBucketListRepository
    {
        private readonly SaiContext _context;

        public BucketListRepository(SaiContext context)
        {
            _context = context;
        }

       
        public async Task<BucketList> GetByIdAsync(int id)
        {
            var item =await _context.BucketLists.FindAsync(id);
            return (item);
        }


        public async Task<IEnumerable<BucketListDto>> GetAllAsync()
        {
            var bucketListItems = await (from c in _context.BucketLists
                                         join p in _context.MenuItems
                                         on c.ItemId equals p.ItemId
                                         select new BucketListDto
                                         {
                                             BucketListID = c.BucketListID,
                                             UserID = c.UserID,
                                             RestaurantId = c.RestaurantId,
                                             ItemId = p.ItemId,
                                             Name = p.Name,
                                             Quantity = c.Quantity,
                                             DateAdded = c.DateAdded
                                         }).ToListAsync();
           


            return bucketListItems;
        }



        public async Task AddAsync(BucketList bucketList)
        {
            _context.BucketLists.Add(bucketList);
            await _context.SaveChangesAsync();
        }

        
        public async Task UpdateAsync(BucketList bucketList)
        {
            _context.BucketLists.Update(bucketList);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var bucketList = await _context.BucketLists.FindAsync(id);
            if (bucketList != null)
            {
                _context.BucketLists.Remove(bucketList);
                await _context.SaveChangesAsync();
            }
        }
    }
}
