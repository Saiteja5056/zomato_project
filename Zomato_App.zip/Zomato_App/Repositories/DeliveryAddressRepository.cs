﻿using Microsoft.EntityFrameworkCore;
using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public class DeliveryAddressRepository : IDeliveryAddressRepository
    {
        private readonly SaiContext _context;

        public DeliveryAddressRepository(SaiContext context)
        {
            _context = context;
        }

        public async Task AddAsync(DeliveryAddress deliveryAddress)
        {
            _context.DeliveryAddresses.Add(deliveryAddress);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var address = await _context.DeliveryAddresses.SingleOrDefaultAsync(d => d.DeliveryPersonnelID == id);
            if (address != null)
            {
                _context.DeliveryAddresses.Remove(address);
                await _context.SaveChangesAsync();
            }
        }

        public async Task UpdateAsync(DeliveryAddress deliveryAddress)
        {
            _context.DeliveryAddresses.Update(deliveryAddress);
            await _context.SaveChangesAsync();
        }
    }
}
