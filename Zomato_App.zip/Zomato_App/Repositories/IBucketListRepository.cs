﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IBucketListRepository
    {
        Task<BucketList> GetByIdAsync(int id);
        Task<IEnumerable<BucketListDto>> GetAllAsync();
        Task AddAsync(BucketList bucketList);
        Task UpdateAsync(BucketList bucketList);
        Task DeleteAsync(int id);
    }
}

