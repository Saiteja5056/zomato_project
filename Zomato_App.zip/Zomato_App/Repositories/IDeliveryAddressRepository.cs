﻿using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IDeliveryAddressRepository
    {
        Task AddAsync(DeliveryAddress deliveryAddress);
        Task UpdateAsync(DeliveryAddress deliveryAddress);
        Task DeleteAsync(int id);
    }
}
