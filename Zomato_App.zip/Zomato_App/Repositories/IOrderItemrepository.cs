﻿using Zomato_App.DTO;
using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IOrderItemrepository
    {
        Task<OrderItem> GetByIdAsync(int id);
        Task<IEnumerable<OrderItem>> GetAllAsync();
        Task AddAsync(OrderItem orderItem);
        Task UpdateAsync(OrderItem orderItem);
        Task DeleteAsync(int id);
    }
}
