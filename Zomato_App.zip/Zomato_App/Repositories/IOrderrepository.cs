﻿using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IOrderrepository
    {
        Task<Order> GetByIdAsync(int id);
        Task<IEnumerable<Order>> GetAllAsync();
        Task AddAsync(Order order);
        Task UpdateAsync(Order order);
        Task DeleteAsync(int id);
    }
}
