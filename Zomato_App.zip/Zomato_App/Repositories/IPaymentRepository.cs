﻿using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IPaymentRepository
    {
        Task AddAsync(Payment payment);
        Task UpdateAsync(Payment payment);
        Task DeleteAsync(int id);
    }
}
