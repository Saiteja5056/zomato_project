﻿using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IRestaurantrepository
    {
        public void AddRestaurant(Restaurant restaurant);
        public List<Restaurant> GetAll();
        public Restaurant GetById(int id);
        public void DeleteById(int id);
        public void Update(Restaurant restaurant);
    }
}
