﻿
using Zomato_App.Entities;

namespace Zomato_App.IRepositories
{
    public interface IUserrepository
    {
        Task<User> GetByIdAsync(int id);
        Task<IEnumerable<User>> GetAllAsync();
        Task AddAsync(User user);
        Task UpdateAsync(User user);
        Task DeleteAsync(int id);
        Task<User> Validate(string email, string password);
    }
}
