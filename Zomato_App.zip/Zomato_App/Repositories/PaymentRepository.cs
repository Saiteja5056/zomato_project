﻿using Zomato_App.Entities;
using Microsoft.EntityFrameworkCore;

namespace Zomato_App.IRepositories
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly SaiContext _context;

        public PaymentRepository(SaiContext context)
        {
            _context = context;
        }

        

        public async Task AddAsync(Payment payment)
        {
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Payment payment)
        {
            _context.Payments.Update(payment);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var payment = await _context.Payments.FindAsync(id);
            if (payment != null)
            {
                _context.Payments.Remove(payment);
                await _context.SaveChangesAsync();
            }

        }
    }
}
