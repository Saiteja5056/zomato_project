﻿using Zomato_App.Entities;
using Microsoft.EntityFrameworkCore;

namespace Zomato_App.IRepositories
{
    public class RestaurantRepository : IRestaurantrepository
    {
        private readonly SaiContext _context;

        public RestaurantRepository(SaiContext context)
        {
            _context = context;
        }

        public void AddRestaurant(Restaurant restaurant)
        {

            _context.Restaurants.Add(restaurant);
            _context.SaveChanges();
        }
        public void DeleteById(int id)
        {
            var restaurant = _context.Restaurants.Find(id);
            _context.Restaurants.Remove(restaurant);
        }

        public List<Restaurant> GetAll()
        {
            return _context.Restaurants.ToList();
        }

        public Restaurant GetById(int id)
        {
            var restaurant = _context.Restaurants.Find(id);
            return (restaurant);

        }

        public void Update(Restaurant restaurant)
        {
           
           
            _context.Restaurants.Update(restaurant);
            _context.SaveChanges();

        }
    }

}
