import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { UserProvider } from './components/UserContext'; // Make sure the path is correct
import Home from './components/Home';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import AddRestaurant from './components/AddRestaurant'; // Import AddRestaurant component
import ManageRestaurants from './components/ManageRestaurants'; // Import ManageRestaurants component
import RestaurantMenu from './components/RestaurantMenu'; 
import Cart from './components/Cart'; // Ensure the file name matches
import Profile from './components/Profile';
import PaymentMethod from './components/PaymentMethod';
import OrderConfirmation from './components/OrderConfirmation';
import ViewOrders from './components/ViewOrders';
import UsersList from './components/UserList';

import MenuManagement from './components/MenuManagement';
const App = () => {
  return (
    <UserProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/user-dashboard" element={<UserDashboard />} />
          <Route path="/add-restaurant" element={<AddRestaurant />} />
          <Route path="/manage-restaurants" element={<ManageRestaurants />} />
          <Route path="/restaurants/:restaurantId/menu" element={<RestaurantMenu />} />
          <Route path="/cart/:userId" element={<Cart />} />
          <Route path="/profile/:userId" element={<Profile />} />
          <Route path="/payment-method" element={<PaymentMethod />} />
          <Route path="/order-confirmation" element={<OrderConfirmation />} />
          <Route path="/view-orders" element={<ViewOrders />} />
          <Route path="/users" element={<UsersList />} />

          <Route path="/menus" element={<MenuManagement />} />
        </Routes>
      </Router>
    </UserProvider>
  );
};

export default App;
