import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AddRestaurant = () => {
  const navigate = useNavigate(); 
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [cuisine, setCuisine] = useState('');
  const [rating, setRating] = useState(0);
  const [description, setDescription] = useState('');
  const [isOpen, setIsOpen] = useState(true);

 
  const handleAddRestaurant = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5178/api/Restaurant/AddRestaurant', {
        name,
        address,
        phoneNumber,
        cuisine,
        rating,
        description,
        isOpen
      });
      alert('Restaurant added successfully');
      
      navigate('/manage-restaurants');
    } catch (error) {
      console.error('Error adding restaurant:', error);
    }
  };

  
  const handleBack = () => {
    navigate('/manage-restaurants');
  };

  return (
    <div className="container mt-5">
      <nav className="navbar navbar-light bg-light">
        <a href="#" className="navbar-brand">Add Restaurant</a>
        <button onClick={handleBack} className="btn btn-secondary">Back to All Restaurants</button>
      </nav>
      <form onSubmit={handleAddRestaurant} className="mt-4">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name"
          required
          className="form-control mb-2"
        />
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Address"
          required
          className="form-control mb-2"
        />
        <input
          type="text"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          placeholder="Phone Number"
          required
          className="form-control mb-2"
        />
        <input
          type="text"
          value={cuisine}
          onChange={(e) => setCuisine(e.target.value)}
          placeholder="Cuisine"
          className="form-control mb-2"
        />
        <input
          type="number"
          value={rating}
          onChange={(e) => setRating(e.target.value)}
          placeholder="Rating (1-5)"
          min="1"
          max="5"
          step="0.1"
          className="form-control mb-2"
        />
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Description"
          className="form-control mb-2"
        />
        <div className="form-check">
          <input
            type="checkbox"
            checked={isOpen}
            onChange={(e) => setIsOpen(e.target.checked)}
            className="form-check-input"
          />
          <label className="form-check-label">Open</label>
        </div>
        <button type="submit" className="btn btn-primary mt-3">Add Restaurant</button>
      </form>
    </div>
  );
};

export default AddRestaurant;
