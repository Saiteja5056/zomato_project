import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from './Navbar'; // Import the Navbar component

const Cart = () => {
  const { userId } = useParams();
  const [cartItems, setCartItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const response = await axios.get('http://localhost:5178/api/BucketList/GetAll');
        const userCartItems = response.data.filter(item => item.userID === parseInt(userId, 10));

        const formattedCartItems = await Promise.all(userCartItems.map(async (item) => {
          const itemResponse = await axios.get(`http://localhost:5178/api/MenuItem/GetById?id=${item.itemId}`);
          const price = itemResponse.data.price;
          const quantity = parseInt(item.quantity, 10);

          return {
            ...item,
            price: isNaN(price) ? 0 : price,
            quantity: isNaN(quantity) ? 1 : quantity
          };
        }));

        setCartItems(formattedCartItems);

        // Calculate total price
        const total = formattedCartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
        setTotalPrice(total);
      } catch (error) {
        console.error('Error fetching cart items:', error);
      }
    };

    fetchCartItems();
  }, [userId]);

  const handleRemoveFromCart = async (bucketListID) => {
    try {
      await axios.delete(`http://localhost:5178/api/BucketList/DeleteItem?id=${bucketListID}`);
      
      // Create a new array after filtering out the removed item based on bucketListID
      const updatedCartItems = cartItems.filter(item => item.bucketListID !== bucketListID);
      
      // Update cartItems state
      setCartItems(updatedCartItems);
      
      // Recalculate the total price using the updated cart items
      const updatedTotalPrice = updatedCartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
      setTotalPrice(updatedTotalPrice);
      
    } catch (error) {
      console.error('Error removing item from cart:', error);
    }
  };

  const handlePlaceOrder = () => {
    navigate('/payment-method');
  };

  return (
    <div>
      <Navbar /> {/* Include the Navbar */}
      <div className="container mt-5">
        <h2>Cart for User ID: {userId}</h2>
        {cartItems.length > 0 ? (
          <>
            <ul className="list-group">
              {cartItems.map((item, index) => {
                const price = item.price || 0;
                const quantity = item.quantity || 1;
                const totalPrice = price * quantity;
                return (
                  <li key={`${item.bucketListID}-${index}`} className="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                      Item ID: {item.itemId} - {item.name} - Quantity: {quantity}
                    </div>
                    <span className="badge bg-primary rounded-pill">${totalPrice.toFixed(2)}</span>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleRemoveFromCart(item.bucketListID)}
                    >
                      Remove
                    </button>
                  </li>
                );
              })}
            </ul>
            <h4 className="mt-4">Total Price: ${totalPrice.toFixed(2)}</h4>
            <button className="btn btn-success mt-3" onClick={handlePlaceOrder}>Place Order</button>
          </>
        ) : (
          <p>No items in cart.</p>
        )}
      </div>
    </div>
  );
};

export default Cart;
