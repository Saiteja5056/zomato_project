import React, { useState } from 'react';
import Login from './Login';
import Signup from './Signup';
import '../global.css'; // Correct path for global.css in src


const Home = () => {
  const [isSignup, setIsSignup] = useState(false);

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-danger">
        <a className="navbar-brand" href="/">Zomato App</a>
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <a className="nav-link" href="#" onClick={() => setIsSignup(false)}>Login</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Home</a>
            </li>
          </ul>
        </div>
      </nav>
      <div className="container text-center mt-5">
        <h1>{isSignup ? 'Sign Up' : 'Login'}</h1>
        {isSignup ? <Signup /> : <Login />}
        <button className="btn btn-link mt-3" onClick={() => setIsSignup(!isSignup)}>
          {isSignup ? 'Already have an account? Login' : 'Don’t have an account? Sign Up'}
        </button>
      </div>
    </div>
  );
};

export default Home;
