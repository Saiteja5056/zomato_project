import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useUser } from './UserContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { login } = useUser();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5178/api/User/Validate', { email, password });
      const { token, role, userId, userName, email: userEmail } = response.data;

      // Log response data to verify fields
      console.log('Login response data:', response.data);

      // Store JWT token in local storage
      localStorage.setItem('jwt', token);

      // Store the user's name in session storage
      sessionStorage.setItem('name', userName);

      // Set user context with user data
      login({ userId, name: userName, email: userEmail, role, jwt: token });

      // Navigate based on user role
      if (role === 'Admin') {
        navigate('/admin-dashboard');
      } else if (role === 'User') {
        navigate('/user-dashboard');
      }
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  return (
    <form onSubmit={handleLogin} className="form">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
        required
        className="form-control"
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        required
        className="form-control"
      />
      <button type="submit" className="btn btn-danger mt-3">Login</button>
    </form>
  );
};

export default Login;
