import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MenuManagement = () => {
  const [restaurants, setRestaurants] = useState([]);
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [newMenuItem, setNewMenuItem] = useState({
    menuId: 1, // Default value, adjust as needed
    name: '',
    price: 0,
    description: '',
    calories: 0,
    availability: true,
  });
  const [itemToUpdate, setItemToUpdate] = useState(null);

  // Fetch all restaurants
  const fetchAllRestaurants = async () => {
    try {
      const response = await axios.get('http://localhost:5178/GetAllRestaurants');
      setRestaurants(response.data);
    } catch (error) {
      console.error('Error fetching restaurants:', error);
    }
  };

  // Fetch menu items for selected restaurant
  const fetchMenuItems = async (restaurantId) => {
    try {
      const response = await axios.get(`http://localhost:5178/api/MenuItem/GetAll`);
      const filteredItems = response.data.filter(item => item.restaurantId === restaurantId);
      setMenuItems(filteredItems);
      setSelectedRestaurant(restaurantId);
    } catch (error) {
      console.error('Error fetching menu items:', error);
    }
  };

  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNewMenuItem(prevState => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Handle update form input change
  const handleUpdateInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setItemToUpdate(prevState => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Add new menu item
  const handleAddMenuItem = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        `http://localhost:5178/api/MenuItem/AddItem`,
        { ...newMenuItem, restaurantId: selectedRestaurant }
      );
      alert('Menu item added successfully');
      setNewMenuItem({
        menuId: 1, // Reset to default value
        name: '',
        price: 0,
        description: '',
        calories: 0,
        availability: true,
      });
      fetchMenuItems(selectedRestaurant); // Refresh menu list after addition
    } catch (error) {
      console.error('Error adding menu item:', error);
      alert('Failed to add menu item');
    }
  };

  // Set the item to update
  const handleEditClick = (item) => {
    setItemToUpdate(item);
  };

  // Update menu item
  const handleUpdateMenuItem = async (e) => {
    e.preventDefault();
    try {
      await axios.put(
        `http://localhost:5178/api/MenuItem/Update?id=${itemToUpdate.itemId}`,
        itemToUpdate,
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
      alert('Menu item updated successfully');
      setItemToUpdate(null); // Clear the form
      fetchMenuItems(selectedRestaurant); // Refresh menu list after update
    } catch (error) {
      console.error('Error updating menu item:', error.response ? error.response.data : error.message);
      alert('Failed to update menu item');
    }
  };

  // Delete menu item
  const handleDeleteMenuItem = async (itemId) => {
    try {
      await axios.delete(`http://localhost:5178/api/MenuItem/Delete?id=${itemId}`);
      alert('Menu item deleted successfully');
      fetchMenuItems(selectedRestaurant); // Refresh menu list after deletion
    } catch (error) {
      console.error('Error deleting menu item:', error);
      alert('Failed to delete menu item');
    }
  };

  useEffect(() => {
    fetchAllRestaurants();
  }, []);

  return (
    <div className="container mt-5">
      <h1>Menu Management</h1>
      <div className="row">
        <div className="col-4">
          <h3>Restaurants</h3>
          <ul className="list-group">
            {restaurants.map(restaurant => (
              <li
                key={restaurant.restaurantId}
                className="list-group-item"
                onClick={() => fetchMenuItems(restaurant.restaurantId)}
                style={{ cursor: 'pointer' }}
              >
                {restaurant.name}
              </li>
            ))}
          </ul>
        </div>

        <div className="col-8">
          <h3>Menu Items</h3>
          {selectedRestaurant && (
            <>
              {/* Form to add new menu item */}
              <form onSubmit={handleAddMenuItem} className="mb-4">
                <input
                  type="number"
                  name="menuId"
                  value={newMenuItem.menuId}
                  onChange={handleInputChange}
                  placeholder="Menu ID"
                  className="form-control mb-2"
                  required
                />
                <input
                  type="text"
                  name="name"
                  value={newMenuItem.name}
                  onChange={handleInputChange}
                  placeholder="Menu Item Name"
                  className="form-control mb-2"
                  required
                />
                <input
                  type="number"
                  name="price"
                  value={newMenuItem.price}
                  onChange={handleInputChange}
                  placeholder="Price"
                  className="form-control mb-2"
                  required
                />
                <textarea
                  name="description"
                  value={newMenuItem.description}
                  onChange={handleInputChange}
                  placeholder="Description"
                  className="form-control mb-2"
                  required
                />
                <input
                  type="number"
                  name="calories"
                  value={newMenuItem.calories}
                  onChange={handleInputChange}
                  placeholder="Calories"
                  className="form-control mb-2"
                  required
                />
                <div className="form-check mb-2">
                  <input
                    type="checkbox"
                    name="availability"
                    checked={newMenuItem.availability}
                    onChange={handleInputChange}
                    className="form-check-input"
                    id="availability"
                  />
                  <label className="form-check-label" htmlFor="availability">
                    Available
                  </label>
                </div>
                <button type="submit" className="btn btn-success">Add Menu Item</button>
              </form>

              {/* Form to update selected menu item */}
              {itemToUpdate && (
                <form onSubmit={handleUpdateMenuItem} className="mb-4">
                  <input
                    type="number"
                    name="menuId"
                    value={itemToUpdate.menuId}
                    onChange={handleUpdateInputChange}
                    placeholder="Menu ID"
                    className="form-control mb-2"
                    required
                  />
                  <input
                    type="text"
                    name="name"
                    value={itemToUpdate.name}
                    onChange={handleUpdateInputChange}
                    placeholder="Menu Item Name"
                    className="form-control mb-2"
                    required
                  />
                  <input
                    type="number"
                    name="price"
                    value={itemToUpdate.price}
                    onChange={handleUpdateInputChange}
                    placeholder="Price"
                    className="form-control mb-2"
                    required
                  />
                  <textarea
                    name="description"
                    value={itemToUpdate.description}
                    onChange={handleUpdateInputChange}
                    placeholder="Description"
                    className="form-control mb-2"
                    required
                  />
                  <input
                    type="number"
                    name="calories"
                    value={itemToUpdate.calories}
                    onChange={handleUpdateInputChange}
                    placeholder="Calories"
                    className="form-control mb-2"
                    required
                  />
                  <div className="form-check mb-2">
                    <input
                      type="checkbox"
                      name="availability"
                      checked={itemToUpdate.availability}
                      onChange={handleUpdateInputChange}
                      className="form-check-input"
                      id="availability"
                    />
                    <label className="form-check-label" htmlFor="availability">
                      Available
                    </label>
                  </div>
                  <button type="submit" className="btn btn-warning">Update Menu Item</button>
                </form>
              )}

              {/* List of menu items with update and delete buttons */}
              <ul className="list-group">
                {menuItems.map(item => (
                  <li key={item.itemId} className="list-group-item d-flex justify-content-between">
                    {item.name} - {item.price} - {item.description} - {item.calories} cal - {item.availability ? 'Available' : 'Unavailable'}
                    <div>
                      <button
                        className="btn btn-warning btn-sm me-2"
                        onClick={() => handleEditClick(item)}
                      >
                        Update
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDeleteMenuItem(item.itemId)}
                      >
                        Delete
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MenuManagement;
