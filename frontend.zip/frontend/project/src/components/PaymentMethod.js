import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const PaymentMethod = () => {
  const [paymentMethod, setPaymentMethod] = useState('');
  const [upiOption, setUpiOption] = useState('');
  const [upiId, setUpiId] = useState('');
  const [selectedBank, setSelectedBank] = useState('');
  const navigate = useNavigate();

  const handlePaymentMethodChange = (e) => {
    setPaymentMethod(e.target.value);
    // Reset additional options when payment method changes
    setUpiOption('');
    setUpiId('');
    setSelectedBank('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Prepare order data
    const orderData = {
      orderId: 0, // Set order ID as needed
      userId: 1, // Replace with actual user ID
      restaurantId: 1, // Replace with actual restaurant ID
      totalAmount: 100, // Replace with actual total amount
      orderStatus: 'Pending',
      paymentStatus: 'Successful',
    };

    try {
      // Send order data to backend
      await axios.post('http://localhost:5178/api/Order/Add', orderData);

      // Redirect to order confirmation page
      navigate('/order-confirmation');
    } catch (error) {
      console.error('Error placing order:', error);
    }
  };

  return (
    <div className="container mt-5">
      <h2>Choose Payment Method</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            id="card"
            name="paymentMethod"
            value="card"
            checked={paymentMethod === 'card'}
            onChange={handlePaymentMethodChange}
          />
          <label className="form-check-label" htmlFor="card">
            Card
          </label>
        </div>
        {paymentMethod === 'card' && (
          <div className="mt-3">
            <h4>Card Details</h4>
            <div className="mb-2">
              <label className="form-label">Card Number</label>
              <input type="text" className="form-control" placeholder="Card Number" required />
            </div>
            <div className="mb-2">
              <label className="form-label">Card Expiry</label>
              <input type="text" className="form-control" placeholder="MM/YY" required />
            </div>
            <div className="mb-2">
              <label className="form-label">CVV</label>
              <input type="text" className="form-control" placeholder="CVV" required />
            </div>
          </div>
        )}

        <div className="form-check mt-3">
          <input
            className="form-check-input"
            type="radio"
            id="upi"
            name="paymentMethod"
            value="upi"
            checked={paymentMethod === 'upi'}
            onChange={handlePaymentMethodChange}
          />
          <label className="form-check-label" htmlFor="upi">
            UPI
          </label>
        </div>
        {paymentMethod === 'upi' && (
          <div className="mt-3">
            <h4>UPI Payment</h4>
            <div className="mb-2">
              <label className="form-label">Choose UPI Option</label>
              <div>
                <input
                  type="radio"
                  id="phonepe"
                  name="upiOption"
                  value="phonepe"
                  checked={upiOption === 'phonepe'}
                  onChange={(e) => setUpiOption(e.target.value)}
                />
                <label htmlFor="phonepe" className="ms-2">PhonePe</label>
              </div>
              <div>
                <input
                  type="radio"
                  id="paytm"
                  name="upiOption"
                  value="paytm"
                  checked={upiOption === 'paytm'}
                  onChange={(e) => setUpiOption(e.target.value)}
                />
                <label htmlFor="paytm" className="ms-2">Paytm</label>
              </div>
              <div>
                <input
                  type="radio"
                  id="gpay"
                  name="upiOption"
                  value="gpay"
                  checked={upiOption === 'gpay'}
                  onChange={(e) => setUpiOption(e.target.value)}
                />
                <label htmlFor="gpay" className="ms-2">Google Pay</label>
              </div>
            </div>
            <div className="mb-2">
              <label className="form-label">UPI ID</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter UPI ID"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                required
              />
            </div>
          </div>
        )}

        <div className="form-check mt-3">
          <input
            className="form-check-input"
            type="radio"
            id="netbanking"
            name="paymentMethod"
            value="netbanking"
            checked={paymentMethod === 'netbanking'}
            onChange={handlePaymentMethodChange}
          />
          <label className="form-check-label" htmlFor="netbanking">
            Net Banking
          </label>
        </div>
        {paymentMethod === 'netbanking' && (
          <div className="mt-3">
            <h4>Net Banking</h4>
            <div className="mb-2">
              <label className="form-label">Select Bank</label>
              <select
                className="form-select"
                value={selectedBank}
                onChange={(e) => setSelectedBank(e.target.value)}
                required
              >
                <option value="">Select Bank</option>
                <option value="bank1">State Bank</option>
                <option value="bank2">Indian Bank</option>
                <option value="bank3">ICICI Bank</option>
                {/* Add more banks as needed */}
              </select>
            </div>
          </div>
        )}

        <button type="submit" className="btn btn-primary mt-3">
          Confirm Payment Method
        </button>
      </form>
    </div>
  );
};

export default PaymentMethod;
