import React, { useEffect, useState } from 'react';
import { useUser } from './UserContext';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Profile = () => {
  const { user } = useUser(); 
  const navigate = useNavigate();
  const [address, setAddress] = useState([]); // State for fetched addresses
  const [newAddress, setNewAddress] = useState({
    deliveryPersonnelID: 0,
    userID: user?.userId || 0, // Automatically set the current user's ID
    name: ''
  }); // State for new address form
  
  // Redirect to login if user is not authenticated
  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else {
      fetchAddress();
    }
  }, [user, navigate]);

  // Fetch user's address based on userId
  const fetchAddress = async () => {
    try {
      const response = await axios.get(`http://localhost:5178/api/DeliveryAddress/GetAll?userId=${user.userId}`);
      setAddress(response.data);
    } catch (error) {
      console.error('Error fetching address:', error);
    }
  };

  // Handle form submission to add a new address
  const handleAddAddress = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5178/api/DeliveryAddress/AddAddress', newAddress);
      console.log('Address added:', response.data);
      fetchAddress(); // Fetch updated addresses after successful submission
    } catch (error) {
      console.error('Error adding address:', error);
    }
  };

  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewAddress({ ...newAddress, [name]: value });
  };

  // Prevent rendering if no user is available
  if (!user) {
    return null;
  }

  console.log('Profile component user data:', user); 

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Profile</h2>
      <div className="card p-4">
        <div className="card-body">
          <h5 className="card-title">User ID: {user.userId}</h5>
          <p className="card-text"><strong>Name:</strong> {user.name}</p>
          <p className="card-text"><strong>Email:</strong> {user.email}</p>
          <p className="card-text"><strong>Role:</strong> {user.role}</p>
        </div>
      </div>

      {/* Form for adding a new delivery address */}
      <div className="mt-4">
        <h4>Add Delivery Address</h4>
        <form onSubmit={handleAddAddress}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Address Name</label>
            <input
              type="text"
              className="form-control"
              id="name"
              name="name"
              value={newAddress.name}
              onChange={handleInputChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">Add Address</button>
        </form>
      </div>

      {/* Display the list of user's delivery addresses */}
      <div className="mt-5">
        <h4>Your Addresses</h4>
        {address.length > 0 ? (
          <ul className="list-group">
            {address.map(addr => (
              <li key={addr.deliveryPersonnelID} className="list-group-item">
                <p><strong>Address ID:</strong> {addr.deliveryPersonnelID}</p>
                <p><strong>Address Name:</strong> {addr.name}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No addresses found.</p>
        )}
      </div>
    </div>
  );
};

export default Profile;
