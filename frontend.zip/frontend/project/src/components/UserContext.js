import React, { createContext, useContext, useState, useEffect } from 'react';

const UserContext = createContext();

export const useUser = () => useContext(UserContext);


export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null); 

 
  useEffect(() => {
    const storedUserId = localStorage.getItem('userId');
    const storedName = localStorage.getItem('name');
    const storedRole = localStorage.getItem('role');
    const storedJwt = localStorage.getItem('jwt');

    if (storedUserId && storedName && storedRole && storedJwt) {  
      setUser({
        userId: storedUserId,
        name: storedName,
        role: storedRole,
        jwt: storedJwt
      });
    }
  }, []);

  
  const login = (userData) => {
    console.log('UserContext login data:', userData); 
    setUser(userData);

    localStorage.setItem('userId', userData.userId);
    localStorage.setItem('name', userData.name);
    localStorage.setItem('role', userData.role);
    localStorage.setItem('jwt', userData.jwt); 
  };

  
  const logout = () => {
    setUser(null);
    localStorage.removeItem('userId');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('jwt'); 
  };

  return (
    <UserContext.Provider value={{ user, login, logout }}>
      {children}
    </UserContext.Provider>
  );
};
