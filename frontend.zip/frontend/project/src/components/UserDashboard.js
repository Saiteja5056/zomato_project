import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useUser } from './UserContext'; 

const UserDashboard = () => {
  const navigate = useNavigate();
  const { user, logout } = useUser(); 
  const [restaurants, setRestaurants] = useState([]);

  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Fetch restaurant data when the component mounts
  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const response = await axios.get('http://localhost:5178/GetAllRestaurants');
        setRestaurants(response.data);
      } catch (error) {
        console.error('Error fetching restaurants:', error);
      }
    };

    fetchRestaurants();
  }, []);

  const restaurantImageUrl = 'https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=100063694935415';

  return (
    <div className="container mt-5">
      <nav className="navbar navbar-light bg-light">
        <Link to={`/profile/${user.userId}`} className="btn btn-primary mx-2">Profile</Link>
        <Link to="/view-orders" className="btn btn-primary mx-2">View Orders</Link>
        <button onClick={handleLogout} className="btn btn-danger mx-2">Logout</button>
      </nav>

      <div className="text-center mt-4">
        <div className="row">
          {restaurants.map((restaurant) => (
            <div key={restaurant.id} className="col-md-4">
              <div className="card mb-4">
                <img
                  src={restaurantImageUrl}
                  className="card-img-top"
                  alt={restaurant.name} 
                  style={{ height: '200px', objectFit: 'cover' }}
                />
                <div className="card-body">
                  <h5 className="card-title">
                    <Link to={`/restaurants/${restaurant.restaurantId}/menu`}>
                      {restaurant.name}
                    </Link>
                  </h5>
                  <p className="card-text">Address: {restaurant.address}</p>
                  <p className="card-text">Rating: {restaurant.rating} / 5</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* View Cart button */}
      <div style={{ position: 'fixed', bottom: '20px', left: '20px' }}>
        <button className="btn btn-secondary" onClick={() => navigate(`/cart/${user.userId}`)}>
          View Cart
        </button>
      </div>
    </div>
  );
};

export default UserDashboard;
