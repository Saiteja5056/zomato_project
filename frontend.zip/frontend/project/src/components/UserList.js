import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useUser } from './UserContext';

const UsersList = () => {
  const [users, setUsers] = useState([]);
  const { user } = useUser(); // Access user context to get the JWT token

  // Function to fetch all users
  const fetchAllUsers = async () => {
    try {
      const response = await axios.get('http://localhost:5178/api/User/GetAllUsers', {
        headers: {
          Authorization: `Bearer ${user.jwt}`, // Include JWT token in headers
        },
      });
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
      alert('Failed to fetch users.');
    }
  };

  useEffect(() => {
    fetchAllUsers(); // Fetch users when component is mounted
  }, []);

  // Handle delete user
  const handleDeleteUser = async (userId) => {
    try {
      const response = await axios.delete('http://localhost:5178/api/User/DeleteUser', {
        headers: {
          Authorization: `Bearer ${user.jwt}`, // Include JWT token
        },
        data: { userId }, // Send user ID in the request body
      });

      alert('User deleted successfully');
      fetchAllUsers(); // Refresh the user list after deletion
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Failed to delete user.');
    }
  };

  return (
    <div className="container mt-5">
      <h1>Users List</h1>
      <ul className="list-group">
        {users.map((user) => (
          <li key={user.userId} className="list-group-item d-flex justify-content-between align-items-center">
            {user.username} - {user.email}
            <button
              className="btn btn-danger btn-sm"
              onClick={() => handleDeleteUser(user.userId)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UsersList;
