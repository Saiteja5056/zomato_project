import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useUser } from './UserContext'; // Import useUser hook

const ViewOrders = () => {
  const navigate = useNavigate();
  const { user } = useUser(); // Get user data from UserContext
  const [orders, setOrders] = useState([]); // State for orders
  const [orderItems, setOrderItems] = useState([]); // State for order items

  // Fetch orders and order items when the component mounts
  useEffect(() => {
    const fetchOrdersAndItems = async () => {
      try {
        // 1. Fetch all orders
        const ordersResponse = await axios.get('http://localhost:5178/api/Order/GetAll');
        const allOrders = ordersResponse.data;
        console.log('All Orders:', allOrders); // Log all orders

        // 2. Filter orders by userId
        const userOrders = allOrders.filter(order => order.userId === user.userId);
        console.log('User Orders:', userOrders); // Log filtered user orders

        setOrders(userOrders); // Store filtered orders

        // 3. Fetch all order items
        const orderItemsResponse = await axios.get('http://localhost:5178/api/OrderItem/GetAll');
        const allOrderItems = orderItemsResponse.data;
        console.log('All Order Items:', allOrderItems); // Log all order items

        // 4. Filter order items based on user's order IDs
        const userOrderItems = allOrderItems.filter(item =>
          userOrders.some(order => order.id === item.orderId)
        );
        console.log('User Order Items:', userOrderItems); 

        setOrderItems(userOrderItems); 
      } catch (error) {
        console.error('Error fetching orders and order items:', error);
      }
    };

    fetchOrdersAndItems();
  }, [user.userId]);


  const handleBack = () => {
    navigate('/user-dashboard'); 
  };

  const handleHelp = () => {
    navigate('/help');
  };

  return (
    <div className="container mt-5">
      <nav className="navbar navbar-light bg-light">
        <button onClick={handleBack} className="btn btn-secondary mx-2">Back</button>
        <button onClick={handleHelp} className="btn btn-info mx-2">Help</button>
      </nav>

      <h2 className="mt-4">Your Orders</h2>
      <div className="list-group mt-4">
        {orders.length === 0 ? (
          <p>No orders found.</p>
        ) : (
          orders.map(order => (
            <div key={order.id} className="list-group-item">
              <h5>Order ID: {order.id}</h5>
              <p>Status: {order.status}</p>

             
              <div className="mt-3">
                <h6>Order Items:</h6>
                {orderItems
                  .filter(item => item.orderId === order.id)
                  .map(item => (
                    <div key={item.orderItemId} className="mt-2">
                      <p>Menu Item ID: {item.menuItemId}</p>
                      <p>Quantity: {item.quantity}</p>
                      <p>Price: ${item.price}</p>
                    </div>
                  ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ViewOrders;
