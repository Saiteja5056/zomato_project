import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useUser } from './UserContext';

const AdminDashboard = () => {
  const [showUserOptions, setShowUserOptions] = useState(false);
  const [showRestaurantOptions, setShowRestaurantOptions] = useState(false);
  const [users, setUsers] = useState([]);
  const [restaurants, setRestaurants] = useState([]);
  const [newRestaurant, setNewRestaurant] = useState({
    name: '',
    address: '',
    phoneNumber: '',
    cuisine: '',
    rating: 5,
    description: '',
    isOpen: true,
  });
  const navigate = useNavigate();
  const { user } = useUser();  // Access user from context

  // Function to fetch all restaurants
  const fetchAllRestaurants = async () => {
    try {
      const response = await axios.get('http://localhost:5178/GetAllRestaurants');
      setRestaurants(response.data);
    } catch (error) {
      console.error('Error fetching restaurants:', error);
    }
  };

  useEffect(() => {
    fetchAllRestaurants();
  }, []);

  // Handle form input changes for all fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewRestaurant({ ...newRestaurant, [name]: value });
  };

  const handleAddRestaurant = async (e) => {
    e.preventDefault();

    if (!user || !user.jwt) {
      alert('User is not authenticated. Please log in.');
      return;
    }

    try {
      const response = await axios.post(
        'http://localhost:5178/AddRestaurant',
        newRestaurant,
        {
          headers: {
            Authorization: `Bearer ${user.jwt}`, // Include the token in the headers
          },
        }
      );

      alert('Restaurant added successfully');
      setNewRestaurant({
        name: '',
        address: '',
        phoneNumber: '',
        cuisine: '',
        rating: 5,
        description: '',
        isOpen: true,
      }); // Clear the form
      fetchAllRestaurants(); // Refresh the restaurant list after addition
    } catch (error) {
      console.error('Error Response:', error.response);
      alert('Failed to add restaurant');
    }
  };

  const handleDeleteRestaurant = async (restaurantId) => {
    if (!user || !user.jwt) {
      alert('User is not authenticated. Please log in.');
      return;
    }

    try {
      const response = await axios.delete('http://localhost:5178/DeleteRestaurant', {
        headers: {
          Authorization: `Bearer ${user.jwt}`,
        },
        data: { restaurantId }, // Sending the restaurant ID as data
      });

      alert('Restaurant deleted successfully');
      fetchAllRestaurants(); // Refresh the restaurant list after deletion
    } catch (error) {
      console.error('Error Response:', error.response);
      alert('Failed to delete restaurant');
    }
  };

  const handleUpdateRestaurant = async (restaurant) => {
    if (!user || !user.jwt) {
      alert('User is not authenticated. Please log in.');
      return;
    }

    const { name, address, phoneNumber } = restaurant;

    try {
      const response = await axios.put(
        `http://localhost:5178/UpdateRestaurant?Name=${encodeURIComponent(name)}&Address=${encodeURIComponent(address)}&PhoneNumber=${encodeURIComponent(phoneNumber)}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${user.jwt}`,
          },
        }
      );

      alert('Restaurant updated successfully');
      fetchAllRestaurants(); // Refresh the restaurant list after update
    } catch (error) {
      console.error('Error Response:', error.response);
      alert('Failed to update restaurant');
    }
  };

  return (
    <div className="container text-center mt-5">
      <h1>Admin Dashboard</h1>
      <div className="mt-4">
        <button
          onClick={() => setShowUserOptions(!showUserOptions)}
          className="btn btn-primary mx-2"
        >
          Users
        </button>
        <button
          onClick={() => setShowRestaurantOptions(!showRestaurantOptions)}
          className="btn btn-primary mx-2"
        >
          Restaurants
        </button>
      </div>

      {/* Restaurant Options */}
      {showRestaurantOptions && (
        <div className="mt-4">
          <h2>Restaurant Management</h2>
          {/* Form to add a new restaurant */}
          <form onSubmit={handleAddRestaurant} className="mt-3">
            <div className="form-group">
              <input
                type="text"
                name="name"
                value={newRestaurant.name}
                onChange={handleInputChange}
                placeholder="Restaurant Name"
                className="form-control mb-2"
                required
              />
              <input
                type="text"
                name="address"
                value={newRestaurant.address}
                onChange={handleInputChange}
                placeholder="Restaurant Address"
                className="form-control mb-2"
                required
              />
              <input
                type="text"
                name="phoneNumber"
                value={newRestaurant.phoneNumber}
                onChange={handleInputChange}
                placeholder="Phone Number"
                className="form-control mb-2"
                required
              />
              <input
                type="text"
                name="cuisine"
                value={newRestaurant.cuisine}
                onChange={handleInputChange}
                placeholder="Cuisine"
                className="form-control mb-2"
                required
              />
              <input
                type="number"
                name="rating"
                value={newRestaurant.rating}
                onChange={handleInputChange}
                placeholder="Rating"
                className="form-control mb-2"
                required
              />
              <textarea
                name="description"
                value={newRestaurant.description}
                onChange={handleInputChange}
                placeholder="Description"
                className="form-control mb-2"
                required
              />
              <label className="d-block">
                <input
                  type="checkbox"
                  name="isOpen"
                  checked={newRestaurant.isOpen}
                  onChange={(e) => setNewRestaurant({ ...newRestaurant, isOpen: e.target.checked })}
                />
                Is Open
              </label>
              <button type="submit" className="btn btn-success mt-2">
                Add Restaurant
              </button>
            </div>
          </form>

          {/* Display restaurant list with delete and update options */}
          <div className="mt-4">
            <h3>Restaurant List</h3>
            <ul className="list-group">
              {restaurants.map((restaurant) => (
                <li key={restaurant.restaurantId} className="list-group-item d-flex justify-content-between align-items-center">
                  {restaurant.name} - {restaurant.address} - {restaurant.phoneNumber} - {restaurant.cuisine}
                  <div>
                    <button
                      className="btn btn-danger btn-sm me-2"
                      onClick={() => handleDeleteRestaurant(restaurant.restaurantId)}
                    >
                      Delete
                    </button>
                    <button
                      className="btn btn-warning btn-sm"
                      onClick={() => handleUpdateRestaurant(restaurant)}
                    >
                      Update
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
