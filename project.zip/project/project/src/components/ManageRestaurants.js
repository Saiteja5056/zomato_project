import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ManageRestaurants = () => {
  const navigate = useNavigate(); // Use navigate for navigation
  const [restaurants, setRestaurants] = useState([]);

  // Function to fetch all restaurants
  const fetchAllRestaurants = async () => {
    try {
      const response = await axios.get('http://localhost:5178/GetAllRestaurants');
      setRestaurants(response.data);
    } catch (error) {
      console.error('Error fetching restaurants:', error);
    }
  };

  // Function to handle restaurant deletion
  const handleDeleteRestaurant = async (restaurantId) => {
    try {
      await axios.delete(`http://localhost:5178/DeleteRestaurant?id=${restaurantId}`);
      alert('Restaurant deleted successfully');
      // Refresh the restaurant list after deletion
      fetchAllRestaurants();
    } catch (error) {
      console.error('Error deleting restaurant:', error);
    }
  };

  // Function to handle navigation back to Admin Dashboard
  const handleBack = () => {
    navigate('/admin-dashboard');
  };

  // Fetch restaurants on component mount
  useEffect(() => {
    fetchAllRestaurants();
  }, []);

  return (
    <div className="container mt-5">
      <nav className="navbar navbar-light bg-light">
        <a href="#" className="navbar-brand">Manage Restaurants</a>
        <button onClick={handleBack} className="btn btn-secondary">Back to Admin Dashboard</button>
      </nav>
      <div className="mt-4">
        <h2>Restaurant Management</h2>
        <button onClick={fetchAllRestaurants} className="btn btn-info mb-3">Refresh List</button>
        {restaurants.length > 0 ? (
          <ul className="list-group">
            {restaurants.map(restaurant => (
              <li key={restaurant.restaurantId} className="list-group-item d-flex justify-content-between align-items-center">
                {restaurant.name} - {restaurant.address}
                <button 
                  onClick={() => handleDeleteRestaurant(restaurant.restaurantId)} 
                  className="btn btn-danger btn-sm"
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No restaurants found.</p>
        )}
      </div>
    </div>
  );
};

export default ManageRestaurants;
