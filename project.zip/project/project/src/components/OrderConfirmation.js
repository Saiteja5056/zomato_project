import React from 'react';
import { useNavigate } from 'react-router-dom';

const OrderConfirmation = () => {
  const navigate = useNavigate();

  const handleBackToDashboard = () => {
    navigate('/user-dashboard');
  };

  return (
    <div className="container mt-5">
      <h2>Order Placed Successfully</h2>
      <p>Your order has been placed successfully. Enjoy the food</p>
      <button className="btn btn-primary mt-3" onClick={handleBackToDashboard}>
        Back to Dashboard
      </button>
    </div>
  );
};

export default OrderConfirmation;
