// Profile.js
import React, { useEffect } from 'react';
import { useUser } from './UserContext';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const { user } = useUser(); // Get user data from UserContext
  const navigate = useNavigate();
 

  // Redirect to login if user is not logged in
  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  // Render nothing if user is not logged in
  if (!user) {
    return null;
  }

  console.log('Profile component user data:', user); // Check if name is present

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Profile</h2>
      <div className="card p-4">
        <div className="card-body">
          <h5 className="card-title">User ID: {user.userId}</h5>
          <p className="card-text"><strong>Name:</strong> {user.name}</p>
          <p className="card-text"><strong>Email:</strong> {user.email}</p>
          <p className="card-text"><strong>Role:</strong> {user.role}</p>
        </div>
      </div>
    </div>
  );
};

export default Profile;
