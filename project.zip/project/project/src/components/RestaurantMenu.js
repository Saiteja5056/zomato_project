import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useUser } from './UserContext';

const RestaurantMenu = () => {
  const { restaurantId } = useParams();
  const [menuItems, setMenuItems] = useState([]);
  const [quantities, setQuantities] = useState({});
  const { user } = useUser(); 
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchMenuItems = async () => {
      try {
        const response = await axios.get('http://localhost:5178/api/MenuItem/GetAll');
        const filteredMenuItems = response.data.filter(
          (item) => item.restaurantId === parseInt(restaurantId, 10)
        );
        setMenuItems(filteredMenuItems);
      } catch (error) {
        console.error('Error fetching menu items:', error);
        setMessage('Failed to fetch menu items.');
      }
    };

    fetchMenuItems();
  }, [restaurantId]);

  const handleQuantityChange = (itemId, newQuantity) => {
    setQuantities((prevQuantities) => ({
      ...prevQuantities,
      [itemId]: newQuantity,
    }));
  };

  const handleAddToCart = async (menuItem) => {
    if (!user || !user.userId) {
      console.log('User is not logged in or userId is missing:', user); 
      setMessage('User not logged in.');
      return;
    }

    const quantity = quantities[menuItem.itemId] || 1;

    const payload = {
      bucketListID: 0, 
      userID: user.userId,
      restaurantId: parseInt(restaurantId, 10),  
      itemId: menuItem.itemId, 
      name: menuItem.name,  
      quantity: quantity,
      dateAdded: new Date().toISOString(),
    };

    console.log('Payload for adding to cart:', payload);

    try {
      const response = await axios.post('http://localhost:5178/api/BucketList/AddItem', payload, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('jwt')}`,
        },
      });
      console.log('Add to cart response:', response.data);
      setMessage('Item added to cart successfully!');
    } catch (error) {
      console.error('Error adding item to cart:', error.response?.data || error.message);
      setMessage('Failed to add item to cart.');
    }
  };

  if (!restaurantId) {
    return <div>Invalid restaurant ID</div>;
  }

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Menu for Restaurant ID: {restaurantId}</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <div className="row">
        {menuItems.length > 0 ? (
          menuItems.map((menuItem) => (
            <div key={menuItem.itemId} className="col-md-6 mb-3">
              <div className="card">
                <div className="card-body d-flex justify-content-between align-items-center">
                  <div className="d-flex flex-column">
                    <h5 className="card-title">{menuItem.name}</h5>
                    <p className="card-text">Price: ${menuItem.price}</p>
                    <p className="card-text">Description: {menuItem.description}</p>
                  </div>
                  <div>
                    <input
                      type="number"
                      min="1"
                      value={quantities[menuItem.itemId] || 1}
                      onChange={(e) => handleQuantityChange(menuItem.itemId, parseInt(e.target.value, 10))}
                      className="form-control mb-2"
                      style={{ width: '80px' }}
                    />
                    <button
                      className="btn btn-primary"
                      onClick={() => handleAddToCart(menuItem)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>No menu items found for this restaurant.</p>
        )}
      </div>
    </div>
  );
};

export default RestaurantMenu;
