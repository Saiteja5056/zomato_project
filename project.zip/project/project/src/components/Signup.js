import React, { useState } from 'react';
import axios from 'axios';

const Signup = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [role, setRole] = useState('User');

  const handleSignup = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5178/api/User/AddUser', { name, email, phoneNumber, password, role })
      .then(() => {
        alert('User registered successfully');
        setName('');
        setEmail('');
        setPhoneNumber('');
        setPassword('');
        setRole('User');
      })
      .catch(error => console.error('Error signing up:', error));
  };

  return (
    <form onSubmit={handleSignup} className="form">
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Name"
        required
        className="form-control"
      />
      <input
        type="tel"
        value={phoneNumber}
        onChange={(e) => setPhoneNumber(e.target.value)}
        placeholder="Phone Number"
        required
        className="form-control"
      />
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
        required
        className="form-control"
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        required
        className="form-control"
      />
      <select value={role} onChange={(e) => setRole(e.target.value)} className="form-control mt-3">
        <option value="User">User</option>
        <option value="Admin">Admin</option>
      </select>
      <button type="submit" className="btn btn-danger mt-3">Sign Up</button>
    </form>
  );
};

export default Signup;
