import React, { createContext, useContext, useState, useEffect } from 'react';

// Create the User Context
const UserContext = createContext();

// Custom hook to use the User Context
export const useUser = () => useContext(UserContext);

// Provider component to wrap around the parts of the app that need access to user data
export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null); // State to store user data

  // Load user data from localStorage when the app starts
  useEffect(() => {
    const storedUserId = localStorage.getItem('userId');
    const storedName = localStorage.getItem('name');
    const storedRole = localStorage.getItem('role');
    const storedJwt = localStorage.getItem('jwt');

    if (storedUserId && storedName && storedRole && storedJwt) {  // Ensure JWT is available
      setUser({
        userId: storedUserId,
        name: storedName,
        role: storedRole,
        jwt: storedJwt
      });
    }
  }, []);

  // Function to update user state when a user logs in
  const login = (userData) => {
    console.log('UserContext login data:', userData); 
    setUser(userData);

    localStorage.setItem('userId', userData.userId);
    localStorage.setItem('name', userData.name);
    localStorage.setItem('role', userData.role);
    localStorage.setItem('jwt', userData.jwt); // Ensure this key matches
  };

  // Function to log out the user
  const logout = () => {
    setUser(null);
    localStorage.removeItem('userId');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('jwt'); // Remove JWT as well
  };

  return (
    <UserContext.Provider value={{ user, login, logout }}>
      {children}
    </UserContext.Provider>
  );
};
