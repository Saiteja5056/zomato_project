import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useUser } from './UserContext'; // Import useUser hook

const ViewOrders = () => {
  const navigate = useNavigate();
  const { user } = useUser(); // Get user data from UserContext
  const [orders, setOrders] = useState([]); // Initialize orders as an empty array

  // Fetch orders when the component mounts
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get(`http://localhost:5178/api/Order/GetAll?userId=${user.userId}`);
        if (Array.isArray(response.data)) {
          setOrders(response.data);
        } else {
          console.error('Unexpected data format:', response.data);
        }
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    };

    fetchOrders();
  }, [user.userId]);

  // Handle navigation
  const handleBack = () => {
    navigate('/user-dashboard'); // Navigate to the User Dashboard
  };

  const handleHelp = () => {
    navigate('/help'); // Navigate to a help page
  };

  return (
    <div className="container mt-5">
      <nav className="navbar navbar-light bg-light">
        <button onClick={handleBack} className="btn btn-secondary mx-2">Back</button>
        <button onClick={handleHelp} className="btn btn-info mx-2">Help</button>
      </nav>

      <h2 className="mt-4">Your Orders</h2>
      <div className="list-group mt-4">
        {orders.length === 0 ? (
          <p>No orders found.</p>
        ) : (
          orders.map((order) => (
            <div key={order.id} className="list-group-item">
              <h5>Order ID: {order.id}</h5>
              <p>Items: {order.items ? order.items.map(item => item.name).join(', ') : 'No items'}</p>
              <p>Total: ${order.totalAmount}</p>
              <p>Status: {order.status}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ViewOrders;
